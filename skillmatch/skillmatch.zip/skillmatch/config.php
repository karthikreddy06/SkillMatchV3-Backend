<?php
return [
    'db' => [
        'dsn' => 'mysql:host=127.0.0.1;port=3307;dbname=skillmatch;charset=utf8mb4',
        'user' => 'root',
        'pass' => ''
    ]
];
